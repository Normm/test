# 12.1.0-beta1 (2024-11-01)

* Updated TOC version for Patch 4.4.1 for Cataclysm Classic.