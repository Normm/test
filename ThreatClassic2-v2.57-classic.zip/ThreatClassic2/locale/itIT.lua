local TC2, C, L, _ = unpack(select(2, ...))
if TC2.locale ~= "itIT" then return end

-----------------------------
-- itIT client
-----------------------------
-- main frame
L.gui_threat = "Minaccia"
