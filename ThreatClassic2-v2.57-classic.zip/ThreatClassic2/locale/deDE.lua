local TC2, C, L, _ = unpack(select(2, ...))
if TC2.locale ~= "deDE" then return end

-----------------------------
-- deDE client
-----------------------------
-- main frame
L.gui_threat = "Bedrohung"
