# Details! Damage Meter

## [Details.20241204.13303.161](https://github.com/Tercioo/Details-Damage-Meter/tree/Details.20241204.13303.161) (2024-12-04)
[Full Changelog](https://github.com/Tercioo/Details-Damage-Meter/compare/Details.20241117.13191.161...Details.20241204.13303.161) 

- Release: Framework, OpenRaid updates + changes from the last 2 weeks.  
- Merge pull request #861 from chris102994/master  
    fix: updating some missing and currently incorrect crowd control spells for cata classic  
- Check if Ebon Might table exists before using it  
- Merge pull request #868 from Gogo1951/patch-2  
    Update Details\_Classic.toc  
- Update Details\_Classic.toc  
    Updated for new game client. Your add-on works great with Anniversary Edition.  
- Fixed class\_damage.lua:307: attempt to compare nil with number  
- Added boon of binding to shared buffs  
- fix: add strangulate  
- fix: add deep freeze  
- fix: adding lock fears for cata  
- fix: adding lock fears for cata  
- fix: updating some missing and currently incorrect crowd control spells for cata classic  
